from redis_dict import RedisDict


teacher_student_db = RedisDict('teacher')

